import 'apollo-cache-inmemory';
import 'apollo-client';
import 'apollo-link-http';
import 'apollo-link-persisted-queries';
import 'apollo-upload-client';
import 'apollo-utilities';
import 'classnames';
import { canUseDOM } from 'exenv';
import 'graphql';
import React from 'react';
import { Helmet } from 'react-helmet';
import NoSSR, { useSSR } from '../components/NoSSR';
import Loading from '../components/Loading';
import { ChildBlock, useChildBlock } from '../components/ChildBlock';
import ExtensionContainer from '../components/ExtensionContainer';
import ExtensionPoint from '../components/ExtensionPoint';
import LayoutContainer from '../components/LayoutContainer';
import LegacyExtensionContainer from '../components/LegacyExtensionContainer';
import Link from '../components/Link';
import { useRuntime, withRuntimeContext } from '../components/RenderContext';
import { buildCacheLocator } from '../utils/client';
import registerComponent from '../utils/registerComponent';
import { withSession } from '../utils/session';
import { useTreePath } from '../utils/treePath';
import withHMR from '../utils/withHMR';
declare const renderExtension: (extensionName: string, destination: HTMLElement, props?: {}) => void;
declare const render: (name: string, runtime: RenderRuntime, element?: HTMLElement | undefined) => Promise<Element | NamedServerRendered>;
declare function start(): void;
declare const RenderContextConsumer: React.ExoticComponent<React.ConsumerProps<RenderContext>>;
declare const TreePathContextConsumer: React.ExoticComponent<React.ConsumerProps<import("../utils/treePath").TreePathProps>>;
export { ExtensionContainer, 
/** Block is the preferred nomenclature now, ExtensionPoint is kept for
 * backwards compatibility
 */
ExtensionPoint as Block, ExtensionPoint, LayoutContainer, LegacyExtensionContainer, Helmet, Link, NoSSR, useSSR, RenderContextConsumer, TreePathContextConsumer, canUseDOM, render, start, withHMR, registerComponent, withRuntimeContext, ChildBlock, useChildBlock, useRuntime, useTreePath, withSession, Loading, buildCacheLocator, renderExtension, ChildBlock as Unstable__ChildBlock, useChildBlock as useChildBlock__unstable, };

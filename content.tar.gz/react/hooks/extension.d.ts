import { ReactElement } from 'react';
interface Options {
    children?: string[] | string;
}
declare const useExtension: ({ children }?: Options) => Extension | null;
interface ExtensionContext {
    extension?: Extension | null;
}
interface Props {
    children({ extension }: ExtensionContext): ReactElement<any> | null;
}
declare const ExtensionConsumer: ({ children }: Props) => ReactElement<any, string | ((props: any) => ReactElement<any, string | any | (new (props: any) => import("react").Component<any, any, any>)> | null) | (new (props: any) => import("react").Component<any, any, any>)> | null;
export { useExtension, ExtensionConsumer };

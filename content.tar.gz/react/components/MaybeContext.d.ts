import { FC } from 'react';
import { RenderContextProps } from './RenderContext';
interface Props extends RenderContextProps {
    nestedPage: string;
    params?: Record<string, any>;
    query?: Record<string, string>;
}
declare const MaybeContext: FC<Props>;
export default MaybeContext;

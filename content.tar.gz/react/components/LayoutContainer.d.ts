import React from 'react';
declare type Element = string | ElementArray;
interface ElementArray extends Array<Element> {
}
interface LayoutContainerProps {
    aboveTheFold?: number;
    elements: Element;
}
declare const LayoutContainer: React.FunctionComponent<LayoutContainerProps>;
export default LayoutContainer;

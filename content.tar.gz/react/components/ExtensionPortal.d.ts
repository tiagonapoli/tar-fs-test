import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { PortalRenderingRequest } from './ExtensionManager';
interface Props {
    extension: PortalRenderingRequest;
}
declare class ExtensionPortal extends Component<Props> {
    static propTypes: {
        extension: PropTypes.Requireable<object>;
    };
    constructor(props: Props);
    render(): React.ReactPortal;
}
export default ExtensionPortal;

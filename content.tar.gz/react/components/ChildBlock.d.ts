import React from 'react';
export declare function useChildBlock(childBlock: ChildBlock): Block | null;
export declare function ChildBlock({ id, children }: ChildBlockProps): React.ReactNode;
interface ChildBlock {
    id: string;
}
/** Placeholder for possible block data in the future */
interface Block {
}
interface ChildBlockProps extends ChildBlock {
    children(block: Block | null): React.ReactNode;
}
export {};

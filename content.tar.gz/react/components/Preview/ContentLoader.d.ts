import { FunctionComponent } from 'react';
interface Props {
    width: number;
    height: number;
    preserveAspectRatio?: string;
}
declare const ContentLoader: FunctionComponent<Props>;
export default ContentLoader;

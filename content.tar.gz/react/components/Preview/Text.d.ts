/// <reference types="react" />
interface Props {
    width: number;
    height: number;
}
declare const Text: ({ width, height }: Props) => JSX.Element;
export default Text;

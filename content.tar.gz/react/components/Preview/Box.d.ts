/// <reference types="react" />
interface Props {
    width: number;
    height: number;
}
declare const Box: ({ width, height }: Props) => JSX.Element;
export default Box;

import React from 'react';
interface Props {
    extension: Extension;
}
interface State {
    containerWidth?: number | null;
}
export declare const TEST_ID = "loading-preview";
export default class Preview extends React.PureComponent<Props, State> {
    private container;
    constructor(props: Props);
    private renderPreviewGraphic;
    componentDidMount(): void;
    private getDimension;
    private getDimensions;
    render(): JSX.Element | null;
}
export {};

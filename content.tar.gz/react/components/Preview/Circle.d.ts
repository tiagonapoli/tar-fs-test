/// <reference types="react" />
interface Props {
    width: number;
    height: number;
}
declare const Circle: ({ width, height }: Props) => JSX.Element;
export default Circle;

/// <reference types="react" />
interface Props {
    width: number;
    height: number;
}
declare const Grid: ({ width, height }: Props) => JSX.Element;
export default Grid;

/// <reference types="react" />
interface Props {
    width: number;
    height: number;
}
declare const Spinner: ({ width, height }: Props) => JSX.Element;
export default Spinner;

import PropTypes from 'prop-types';
import { Component } from 'react';
export interface PortalRenderingRequest {
    extensionName: string;
    destination: HTMLElement;
    props: any;
}
interface Props {
    runtime: RenderRuntime;
}
interface State {
    extensionsToRender: PortalRenderingRequest[];
}
declare class ExtensionManager extends Component<Props, State> {
    static propTypes: {
        runtime: PropTypes.Requireable<object>;
    };
    constructor(props: Props);
    componentDidMount(): void;
    componentWillUnmount(): void;
    updateExtensions: (extension: PortalRenderingRequest) => void;
    render(): JSX.Element[];
    private addOrUpdateExtension;
}
export default ExtensionManager;

import { FC } from 'react';
interface Props {
    page: string;
    query?: Record<string, string>;
}
declare const RenderPage: FC<Props>;
export default RenderPage;

import React from 'react';
import { NavigateOptions } from '../utils/pages';
interface Props extends NavigateOptions {
    onClick: (event: React.MouseEvent) => void;
}
declare const Link: React.FunctionComponent<Props>;
export default Link;

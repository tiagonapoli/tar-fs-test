/// <reference types="react" />
interface Props {
    id: string;
    key?: string;
    params?: any;
    query?: any;
    treePath?: string;
    blockProps?: object;
}
declare const _default: {
    (props: Props): JSX.Element;
    displayName: string;
};
export default _default;

import React, { FunctionComponent } from 'react';
declare const ErrorBoundaryWithContext: FunctionComponent;
export default ErrorBoundaryWithContext;
export declare const withErrorBoundary: <P extends object>(Component: React.ComponentType<P>) => {
    (props: P): JSX.Element;
    displayName: string;
};

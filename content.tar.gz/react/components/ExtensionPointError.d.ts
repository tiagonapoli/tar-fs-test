import PropTypes from 'prop-types';
import { ErrorInfo, PureComponent } from 'react';
interface Props {
    treePath?: string;
    error?: Error;
    errorInfo?: ErrorInfo | null;
    operationIds?: string[];
}
interface State {
    errorDetails?: boolean;
}
declare class ExtensionPointError extends PureComponent<Props, State> {
    static propTypes: {
        error: PropTypes.Requireable<object>;
        errorInfo: PropTypes.Requireable<object>;
        treePath: PropTypes.Requireable<string>;
    };
    constructor(props: any);
    handleToggleErrorDetails: () => void;
    render(): JSX.Element;
}
export default ExtensionPointError;

import { FC } from 'react';
interface Props {
    id: string | null;
}
declare const ExtensionContainer: FC<Props>;
export default ExtensionContainer;

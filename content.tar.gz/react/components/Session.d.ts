import { FunctionComponent } from 'react';
declare const Session: FunctionComponent;
export default Session;

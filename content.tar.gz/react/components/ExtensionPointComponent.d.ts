import PropTypes from 'prop-types';
import { ErrorInfo, PureComponent } from 'react';
import { RenderContextProps } from './RenderContext';
interface Props {
    component: string | null;
    props: any;
    treePath: string;
}
interface State {
    error?: Error | null;
    errorInfo?: ErrorInfo | null;
    operationIds: string[];
    lastUpdate?: number;
}
declare class ExtensionPointComponent extends PureComponent<Props & RenderContextProps, State> {
    static propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        component: PropTypes.Requireable<string>;
        props: PropTypes.Requireable<object>;
        runtime: PropTypes.Requireable<object>;
        treePath: PropTypes.Requireable<string>;
    };
    private _isMounted;
    private mountedError;
    constructor(props: Props & RenderContextProps);
    updateComponentsWithEvent: (component: string) => boolean;
    fetchAndRerender: () => void;
    clearError: () => void;
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    componentDidMount(): void;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    render(): JSX.Element | null;
    private addDataToElementIfEditable;
    private removeDataFromElement;
}
export default ExtensionPointComponent;

import React from 'react';
export interface RenderContextProps {
    runtime: RenderContext;
}
export interface EmitterProps {
    __emitter: RenderContext['emitter'];
}
export declare const RenderContext: React.Context<RenderContext>;
export declare const RenderContextProvider: React.FC<RenderContextProps>;
export declare const useRuntime: () => RenderContext;
export declare const withRuntimeContext: <TOriginalProps extends {} = {}>(Component: React.ComponentType<TOriginalProps & RenderContextProps>) => React.ComponentType<TOriginalProps>;
export declare const withEmitter: <TOriginalProps extends {} = {}>(Component: React.ComponentType<TOriginalProps & EmitterProps>) => React.ComponentType<TOriginalProps>;

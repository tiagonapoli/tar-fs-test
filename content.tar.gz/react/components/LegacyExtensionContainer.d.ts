import { FC } from 'react';
interface Props {
    query: any;
    params: any;
}
declare const LegacyExtensionContainer: FC<Props>;
export default LegacyExtensionContainer;

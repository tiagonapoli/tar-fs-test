import React, { FunctionComponent } from 'react';
declare const useSSR: () => boolean;
interface Props {
    onSSR?: React.ReactNode;
}
declare const NoSSR: FunctionComponent<Props>;
export default NoSSR;
export { useSSR };

import React from 'react';
declare const _default: React.ComponentType<{}>;
export default _default;

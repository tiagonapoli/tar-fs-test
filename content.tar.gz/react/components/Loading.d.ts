/// <reference types="react" />
declare const Loading: () => JSX.Element | null;
export default Loading;

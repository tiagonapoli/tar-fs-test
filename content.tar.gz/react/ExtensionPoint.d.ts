import { ExtensionPoint } from 'vtex.render-runtime';
export default ExtensionPoint;

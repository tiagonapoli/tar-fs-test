/// <reference types="react" />
import 'react-amphtml';
import 'react-amphtml/helpers';
export declare const setupAMP: (root: JSX.Element, renderFn: any, runtime: RenderRuntime) => {
    ampRoot: JSX.Element;
    getExtraRenderedData: () => {
        ampScripts: any;
        ampHeadBoilerplate: any;
    };
};

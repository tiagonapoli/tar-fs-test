import { LegacyExtensionContainer } from 'vtex.render-runtime';
export default LegacyExtensionContainer;

export declare const fetchServerPage: ({ fetcher, path, query: rawQuery, }: {
    path: string;
    query?: Record<string, string> | undefined;
    fetcher: (input: RequestInfo, init?: RequestInit | undefined) => Promise<Response>;
}) => Promise<ParsedServerPageResponse>;
export declare const fetchNavigationPage: ({ apolloClient, routeId, declarer, production, paramsJSON, renderMajor, skipCache, query, }: FetchNavigationDataInput) => Promise<ParsedPageQueryResponse>;
export declare const fetchDefaultPages: ({ apolloClient, pages, routeIds, renderMajor, }: FetchDefaultPages) => Promise<ParsedDefaultPagesQueryResponse>;

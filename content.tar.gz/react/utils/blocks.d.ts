export declare const withStar: (treePath: string) => string;
export declare const generateExtensions: (blocksTree: Record<string, TreeEntry>, blocks: Record<string, BlockEntry>, contentMap: ContentMap, page: Page) => Extensions;

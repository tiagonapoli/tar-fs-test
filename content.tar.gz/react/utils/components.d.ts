export declare const traverseComponent: (components: Components | Record<string, string[]>, component: string) => ComponentTraversalResult;

export default class PageCacheControl {
    private maxAges;
    readonly maxAge: number;
    evaluate(innerResponse: Response): void;
}

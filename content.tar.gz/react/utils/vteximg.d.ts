export declare function optimizeSrcForVtexImg(vtexImgHost: string, src?: any): any;
export declare function optimizeStyleForVtexImg(vtexImgHost: string, style?: any): any;
export declare function isStyleWritable(props: any): boolean;

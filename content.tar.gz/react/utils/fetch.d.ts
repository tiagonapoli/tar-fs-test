export declare const fetchWithRetry: (url: string, init: RequestInit, fetcher: (input: RequestInfo, init?: RequestInit | undefined) => Promise<Response>, maxRetries?: number) => Promise<{
    response: Response;
    error: any;
}>;

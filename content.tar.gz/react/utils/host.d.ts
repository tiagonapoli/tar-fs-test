export declare const getBaseURI: (runtime: RenderRuntime) => string;

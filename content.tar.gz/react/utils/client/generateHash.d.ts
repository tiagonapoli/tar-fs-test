import { DocumentNode } from 'graphql';
interface HashedDocumentNode extends DocumentNode {
    documentId: string;
}
export declare const generateHash: (query: DocumentNode | HashedDocumentNode) => string;
export {};

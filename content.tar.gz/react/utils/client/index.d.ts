import { NormalizedCacheObject } from 'apollo-cache-inmemory';
import { ApolloClient } from 'apollo-client';
import { ApolloLink } from 'apollo-link';
import PageCacheControl from '../cacheControl';
export declare const buildCacheLocator: (app: string, type: string, cacheId: string) => string;
export declare const getState: (runtime: RenderRuntime) => NormalizedCacheObject;
export declare const getClient: (runtime: RenderRuntime, baseURI: string, runtimeContextLink: ApolloLink, ensureSessionLink: ApolloLink, fetcher: (input: RequestInfo, init?: RequestInit | undefined) => Promise<Response>, cacheControl?: PageCacheControl | undefined) => ApolloClient<NormalizedCacheObject>;

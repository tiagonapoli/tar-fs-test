import { ApolloLink } from 'apollo-link';
import PageCacheControl from '../../cacheControl';
export declare const cachingLink: (cacheControl: PageCacheControl) => ApolloLink;

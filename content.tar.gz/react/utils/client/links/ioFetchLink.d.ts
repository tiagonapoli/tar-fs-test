import { ApolloLink } from 'apollo-link';
export declare const createIOFetchLink: (httpLink: ApolloLink, uploadLink: ApolloLink) => ApolloLink;

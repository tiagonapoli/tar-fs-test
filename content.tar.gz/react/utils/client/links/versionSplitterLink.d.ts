import { ApolloLink } from 'apollo-link';
export declare const versionSplitterLink: ApolloLink;

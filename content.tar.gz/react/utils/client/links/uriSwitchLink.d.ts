import { ApolloLink } from 'apollo-link';
export interface OperationContext {
    fetchOptions: any;
    runtime: Pick<RenderRuntime, 'appsEtag' | 'cacheHints' | 'components' | 'culture' | 'extensions' | 'messages' | 'pages'>;
}
export declare const createUriSwitchLink: (baseURI: string, initialRuntime: RenderRuntime) => ApolloLink;

import React from 'react';
export declare const RENDER_CONTAINER_CLASS = "render-container";
export declare const ROUTE_CLASS_PREFIX = "render-route-";
export declare const routeClass: (name: string) => string;
export declare const createPortal: (children: React.ReactElement<any, string | ((props: any) => React.ReactElement<any, string | any | (new (props: any) => React.Component<any, any, any>)> | null) | (new (props: any) => React.Component<any, any, any>)>, name: string, hydrate: boolean) => JSX.Element | null;
export declare const getMarkups: (pageName: string, pageMarkup: string) => NamedMarkup[];
export declare const isSiteEditorIframe: boolean;
export declare const getContainer: () => Element | null;
export declare const ensureContainer: (name: string) => boolean;

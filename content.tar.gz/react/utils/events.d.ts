export declare const registerEmitter: (runtime: RenderRuntime, baseURI: string) => void;

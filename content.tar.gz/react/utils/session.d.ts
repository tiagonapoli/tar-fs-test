import React from 'react';
export declare const withSession: () => <TOriginalProps>(Component: React.ComponentType<TOriginalProps>) => React.ComponentType<TOriginalProps>;

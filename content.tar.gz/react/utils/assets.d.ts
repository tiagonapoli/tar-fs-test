export declare const getVTEXImgHost: (account: string) => string;
export declare function addScriptToPage(src: string): Promise<void>;
export declare function shouldAddScriptToPage(path: string, scripts?: string[]): boolean;
export declare function getImplementation<P = {}, S = {}>(component: string): RenderComponent<P, S>;
export declare function getExtensionImplementation<P = {}, S = {}>(extensions: Extensions, name: string): RenderComponent<P, S> | null;
export declare function fetchAssets(runtime: RenderRuntime, componentsAssetsMap: ComponentTraversalResult): Promise<void>;
export declare function prefetchAssets(runtime: RenderRuntime, componentsAssetsMap: ComponentTraversalResult): void;

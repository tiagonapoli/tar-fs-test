declare const _default: (module: Module, InitialImplementer: any) => any;
export default _default;

import React, { ComponentType, FC } from 'react';
export declare const escapeRegex: (s: string) => string;
export declare const isDirectChild: (id: string, parent: string) => boolean;
export declare const getDirectChildren: (extensions: Extensions, treePath: string) => string[];
export declare const TreePathContext: React.Context<TreePathProps>;
export declare const TreePathContextProvider: FC<TreePathProps>;
export declare const useTreePath: () => TreePathProps;
export interface TreePathProps {
    treePath: string;
}
export declare function withTreePath<TOriginalProps>(Component: ComponentType<TOriginalProps & TreePathProps>): ComponentType<TOriginalProps>;

export declare const loadLocaleData: (locale: string) => Promise<[void, void]>;
export declare const addLocaleData: (locale: string) => void;

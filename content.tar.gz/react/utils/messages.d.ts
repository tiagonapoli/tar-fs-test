export declare const parseMessages: (messages: KeyedString[] | null) => {
    [index: string]: string;
} | null;

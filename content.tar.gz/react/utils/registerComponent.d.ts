import { ComponentType } from 'react';
export declare const isComponentType: (Arg: any) => Arg is ComponentType<{}>;
declare const _default: (module: Module, InitialImplementer: any, app: string, name: string) => any;
export default _default;

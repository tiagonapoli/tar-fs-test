export declare const isEnabled: (flag: "RENDER_NAVIGATION") => boolean;

import { LayoutContainer } from 'vtex.render-runtime';
export default LayoutContainer;

import { ExtensionContainer } from 'vtex.render-runtime';
export default ExtensionContainer;
